import { Component, OnInit } from '@angular/core';
import { Weather } from '../weather.model';

@Component({
  selector: 'app-weather-root',
  templateUrl: './weather-root.component.html',
  styleUrls: ['./weather-root.component.scss']
})
export class WeatherRootComponent implements OnInit {

  constructor() { }

  listOfshowRoot: Weather[];

  ngOnInit() {
    this.listOfshowRoot = [
      { Summary: 'one', TemperatureC: 1, TemperatureF: 2, datetime: 'date'}
    ];
  }

}
