export interface Weather {
    datetime: string;
    TemperatureC: number;
    TemperatureF: number;
    Summary: string;
}

