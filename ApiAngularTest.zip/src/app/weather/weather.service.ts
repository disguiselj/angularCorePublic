import { Injectable } from '@angular/core';
import { observable } from 'rxjs';
import { Weather } from '../weather/weather.model';


@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  constructor() { }
  lotsOfweather: Weather[];


  getTheWeather() {

  }


}
