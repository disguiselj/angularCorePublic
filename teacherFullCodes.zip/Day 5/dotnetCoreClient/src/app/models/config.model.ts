export interface ConfigModel {
    serverUrl: string;
    showServiceUrl: string;
}