export interface Person {
    id?: number;
    name: string;
    email: string;
    birthdate: Date;
}