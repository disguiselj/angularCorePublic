import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-edit-add',
  templateUrl: './products-edit-add.component.html',
  styleUrls: ['./products-edit-add.component.scss']
})
export class ProductsEditAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
