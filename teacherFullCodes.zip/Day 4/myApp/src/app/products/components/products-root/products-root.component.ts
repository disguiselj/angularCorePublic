import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-root',
  templateUrl: './products-root.component.html',
  styleUrls: ['./products-root.component.scss']
})
export class ProductsRootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
