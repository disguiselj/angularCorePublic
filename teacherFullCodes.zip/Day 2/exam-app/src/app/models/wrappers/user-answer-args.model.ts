import { QA } from '../qa.model';

export interface UserAnswerArgs {
    userAnswer: string;
    question: QA;
}