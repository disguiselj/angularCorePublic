import { Component } from '@angular/core';
import { ShowServiceService } from './shows/components/show-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'database';

  constructor(private showService: ShowServiceService) { }
}
