import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ShowrootComponent } from './show-roow/showroot/showroot.component';
import { ShowListComponent } from './components/show-list/show-list.component';



@NgModule({
  declarations: [ ShowrootComponent, ShowListComponent],
  imports: [
    CommonModule
  ],
  exports: [ShowrootComponent]
})
export class ShowsModule { }
