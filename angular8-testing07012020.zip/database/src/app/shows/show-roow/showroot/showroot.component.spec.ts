import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowrootComponent } from './showroot.component';

describe('ShowrootComponent', () => {
  let component: ShowrootComponent;
  let fixture: ComponentFixture<ShowrootComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowrootComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowrootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
