import { Component, OnInit } from '@angular/core';
import { Show } from '../../models/shows.model';

@Component({
  selector: 'app-showroot',
  templateUrl: './showroot.component.html',
  styleUrls: ['./showroot.component.scss']
})
export class ShowrootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    showsFromRoot: Show[] = [];

  }

}
