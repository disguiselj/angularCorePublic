export interface Show {
    id: number;
    name: string;
    imgUrl: string;
    price: number;
}
