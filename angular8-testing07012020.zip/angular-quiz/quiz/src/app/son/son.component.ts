import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { QuizClass } from '../quiz-class.module';

@Component({
  selector: 'app-son',
  templateUrl: './son.component.html',
  styleUrls: ['./son.component.scss']
})
export class SonComponent implements OnInit {

  @Input() quizList: QuizClass[] = null;


  @Output() youclickhere = new EventEmitter<QuizClass>();




  iclickedhere(q: QuizClass) {
    this.youclickhere.emit(q);

  }
  constructor() { }

  ngOnInit() {
  }

}
