import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SonComponent } from './son/son.component';
import { UsingpipeComponent } from './usingpipe/usingpipe.component';
import { TokPipe } from './usingpipe/tok.pipe';
import { TohmPipe } from './usingpipe/tohm.pipe';

@NgModule({
  declarations: [
    AppComponent,
    SonComponent,
    UsingpipeComponent,
    TokPipe,
    TohmPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
