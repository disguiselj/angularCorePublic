export interface QuizClass {
    quastion: string;
    answerOptions: string[];
    CurrctAnswer: string;
    timeLeft: number;
    userAnswer: string;
    status: string;
}
