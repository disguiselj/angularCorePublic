import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tok'
})
export class TokPipe implements PipeTransform {

  transform(value: number, ...args: any[]): any {
    return value < 1000 ? value.toString() : value / 1000 + 'k';
  }

}
