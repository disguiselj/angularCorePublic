import { TokPipe } from './tok.pipe';

describe('TokPipe', () => {
  it('create an instance', () => {
    const pipe = new TokPipe();
    expect(pipe).toBeTruthy();
  });
});
