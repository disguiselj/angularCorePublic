import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tohm'
})
export class TohmPipe implements PipeTransform {

  transform(value: number, ...args: any[]): any {
    return parseInt((value / 60).toString(), 10) + (value % 60 === 0 ? '' : ':' + value % 60);
  }

}
