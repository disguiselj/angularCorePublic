import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsingpipeComponent } from './usingpipe.component';

describe('UsingpipeComponent', () => {
  let component: UsingpipeComponent;
  let fixture: ComponentFixture<UsingpipeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsingpipeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsingpipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
