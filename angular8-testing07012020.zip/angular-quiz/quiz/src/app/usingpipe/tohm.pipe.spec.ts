import { TohmPipe } from './tohm.pipe';

describe('TohmPipe', () => {
  it('create an instance', () => {
    const pipe = new TohmPipe();
    expect(pipe).toBeTruthy();
  });
});
