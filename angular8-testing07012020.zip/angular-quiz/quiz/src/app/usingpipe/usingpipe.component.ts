import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usingpipe',
  templateUrl: './usingpipe.component.html',
  styleUrls: ['./usingpipe.component.scss']
})
export class UsingpipeComponent implements OnInit {


  numberToConvert = 5000;
  minutes = 130;

  constructor() { }

  ngOnInit() {
  }

}
