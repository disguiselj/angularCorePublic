import { Component } from '@angular/core';
import { QuizClass } from '../app/quiz-class.module';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'quiz';

  thisQuizObject: QuizClass = null;

  thisCompFunction(s: QuizClass) {
    this.thisQuizObject = s;
    //window.setTimeout(this.beep, 555);
    const a = window.setInterval(() => {
      this.thisQuizObject.timeLeft -= 1000;
      if (this.thisQuizObject.timeLeft < 0) {
        alert(this.thisQuizObject.quastion);
        this.thisQuizObject.timeLeft = 0;
        clearTimeout(a);
      }
    }, 1000);
  }




  beep() {
    alert(this.thisQuizObject.quastion);
  }

  bab: QuizClass[] = [{
    quastion: 'a',
    answerOptions: ['fff', 'ffffff'],
    CurrctAnswer: 'fff',
    timeLeft: 3000,
    userAnswer: 'fff',
    status: 'fff'
  },
  {
    quastion: 'b',
    answerOptions: ['fff', 'ffffff'],
    CurrctAnswer: 'fff',
    timeLeft: 3000,
    userAnswer: 'fff',
    status: 'fff'
  },
  {
    quastion: 'c',
    answerOptions: ['fff', 'ffffff'],
    CurrctAnswer: 'fff',
    timeLeft: 3000,
    userAnswer: 'fff',
    status: 'fff'
  },
  {
    quastion: 'd',
    answerOptions: ['fff', 'ffffff'],
    CurrctAnswer: 'fff',
    timeLeft: 3000,
    userAnswer: 'fff',
    status: 'fff'
  },
  {
    quastion: 'e',
    answerOptions: ['fff', 'ffffff'],
    CurrctAnswer: 'fff',
    timeLeft: 3000,
    userAnswer: 'fff',
    status: 'fff'
  }
  ];
}
