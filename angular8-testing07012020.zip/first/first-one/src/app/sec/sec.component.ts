import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sec',
  templateUrl: './sec.component.html',
  styleUrls: ['./sec.component.scss']
})
export class SecComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
