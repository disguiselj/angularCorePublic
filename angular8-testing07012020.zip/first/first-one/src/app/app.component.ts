import { Component, Directive } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'first-one';

  arrayOfImgNames: Array<string> = [];


/**
 *
 */
constructor() {
 this.loadData();
  
}

imageName(aaa:string ){
  alert(aaa);
}
  loadData() {
  for (let index = 0; index <= 4; index++) {
    this.arrayOfImgNames.push('arrr'  + index.toString() );

  }
}

}


