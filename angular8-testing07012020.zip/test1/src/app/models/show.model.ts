interface RootObject {
    shows: Show2[];
}

interface Show2 {
    show: Show;
    genres: string[];
    id: number;
    image?: Image;
    medium?: string;
    original?: string;
    name: string;
    status: string;
    summary: string;
}

export interface Show {
    id: number;
    url: string;
    name: string;
    type: string;
    language: string;
    genres: string[];
    status: string;

}

interface Links {
    self: Self;
    previousepisode?: Self;
    nextepisode?: Self;
}

interface Self {
    href: string;
}

interface Image {
    medium: string;
    original: string;
}

interface Externals {
    tvrage?: number;
    thetvdb?: number;
    imdb?: string;
}

interface WebChannel {
    id: number;
    name: string;
    country?: Country;
}

interface Network {
    id: number;
    name: string;
    country: Country;
}

interface Country {
    name: string;
    code: string;
    timezone: string;
}

interface Rating {
    average?: number;
}

interface Schedule {
    time: string;
    days: string[];
}
