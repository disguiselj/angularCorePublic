import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ShowRootComponent } from './shows/components/show-root/show-root.component';
import { ShowListComponent } from './shows/components/show-list/show-list.component';
import { ShowSingleComponent } from './shows/components/show-single/show-single.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ShowRootComponent,
    ShowListComponent,
    ShowSingleComponent
  ],
  imports: [
    BrowserModule, HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
