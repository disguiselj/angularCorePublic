import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Show } from 'src/app/models/show.model';
import { Observable, observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShowServService {

  constructor(private httpObj: HttpClient) { }

  giveMeAlldataNow(): Observable<Show[]> {
    return this.httpObj.get<Show[]>('http://localhost:3000/shows');
  }

}
