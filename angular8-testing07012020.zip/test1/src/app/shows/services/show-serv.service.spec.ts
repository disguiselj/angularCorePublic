import { TestBed } from '@angular/core/testing';

import { ShowServService } from './show-serv.service';

describe('ShowServService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ShowServService = TestBed.get(ShowServService);
    expect(service).toBeTruthy();
  });
});
