import { Component, OnInit, Input } from '@angular/core';
import { Show } from 'src/app/models/show.model';

@Component({
  selector: 'app-show-single',
  templateUrl: './show-single.component.html',
  styleUrls: ['./show-single.component.scss']
})
export class ShowSingleComponent implements OnInit {

  constructor() { }

  @Input() thisShow: Show;

  ngOnInit() {
  }

}
