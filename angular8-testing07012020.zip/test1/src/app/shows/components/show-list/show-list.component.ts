import { Component, OnInit, Input } from '@angular/core';
import { Show } from '../../../models/show.model';


@Component({
  selector: 'app-show-list',
  templateUrl: './show-list.component.html',
  styleUrls: ['./show-list.component.scss']
})
export class ShowListComponent implements OnInit {

  constructor() { }
  @Input() shows: Show[] = [];
  SelectedShow: Show;


  GoToSon(s: Show) {
    this.SelectedShow = s;

  }

  ngOnInit() {
  }

}
