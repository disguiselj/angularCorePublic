import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowRootComponent } from './show-root.component';

describe('ShowRootComponent', () => {
  let component: ShowRootComponent;
  let fixture: ComponentFixture<ShowRootComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowRootComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
