import { Component, OnInit } from '@angular/core';
import { Show } from '../../../models/show.model';
import { ShowServService } from '../../services/show-serv.service';


@Component({
  selector: 'app-show-root',
  templateUrl: './show-root.component.html',
  styleUrls: ['./show-root.component.scss']
})
export class ShowRootComponent implements OnInit {

  shows: Show[] = [];

  constructor(private showService: ShowServService) { }

  hideOrNotvar = false;
  ngOnInit() {

    this.showService.giveMeAlldataNow().subscribe(
      result => {
        this.shows = result;
      }
    );
    //this.loadListOfShows();
  }
  hideOrNot() {
    this.hideOrNotvar = !this.hideOrNotvar;

  }
  loadListOfShows() {
    this.shows = [{
      id: 139,
      'url': 'http://www.tvmaze.com/shows/139/girls',
      'name': 'Girls',
      'type': 'Scripted',
      'language': 'English',
      'genres': [
        'Drama',
        'Romance'
      ],
      'status': 'Ended'
    },
    {
      'id': 23542,
      'url': 'http://www.tvmaze.com/shows/23542/good-girls',
      'name': 'Good Girls',
      'type': 'Scripted',
      'language': 'English',
      'genres': [
        'Drama',
        'Comedy',
        'Crime'
      ],
      'status': 'Running'
    },
    {
      'id': 1073,
      'url': 'http://www.tvmaze.com/shows/1073/bomb-girls',
      'name': 'Bomb Girls',
      'type': 'Scripted',
      'language': 'English',
      'genres': [
        'Drama',
        'Romance',
        'War'
      ],
      'status': 'Ended'
    }
    ];
  }





}
