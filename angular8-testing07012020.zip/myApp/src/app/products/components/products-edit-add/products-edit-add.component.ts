import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductsService } from '../../services/products.service';
import { Product } from 'src/app/models/products.model';
import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";

@Component({
  selector: 'app-products-edit-add',
  templateUrl: './products-edit-add.component.html',
  styleUrls: ['./products-edit-add.component.scss']
})
export class ProductsEditAddComponent implements OnInit {

  constructor(private activatedRoute: ActivatedRoute, private pservice: ProductsService , private fb: FormBuilder) { }

  p: Product;

  ngOnInit() {
    this.activatedRoute.params.subscribe(o => {
       this.pservice.getProductById(o.pid).subscribe(result => {
          this.p = result;
       });


    });
  }

}
